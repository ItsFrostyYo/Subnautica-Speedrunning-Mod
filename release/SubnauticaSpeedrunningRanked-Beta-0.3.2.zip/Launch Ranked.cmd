@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0SubnauticaSpeedrunningRanked\Launch Ranked.exe" %*
